#include <stdio.h>
#include <windows.h>
#include <stdlib.h>

typedef struct Node
{
    int data;
    struct Node *next;
}Node, *LinkedList;

typedef enum Status
{
    error,
    success
}Status;

Status InitList(LinkedList *L);
void DestoryList(LinkedList *L);
Status InsertList(Node *p,int data);
Status DeleteList(Node *p,int e);
void TraverseList(LinkedList L);
Status SearchList(LinkedList L,int e);
Status ReverseList(LinkedList *L);
Status IsLoopList(LinkedList L);
Node* FindMidNode(LinkedList L);
char MenuText[11][11];
int judge(void);

Status InitList(LinkedList *L)
{
    LinkedList list;
    list = (LinkedList)malloc(sizeof(Node));
    if(list == NULL)
    {
        printf("内存分配失败\n");
        return error;
    }
    list->next = NULL;
    *L = list;
    return success;
}

void DestoryList(LinkedList *L){
    LinkedList temp;
    while(*L != NULL)
    {
        temp = *L;
        *L = (*L)->next;
        free(temp);  
    }
}

Status InsertList(Node *p,int data){
    LinkedList current = p;
    LinkedList newNode = (LinkedList)malloc(sizeof(Node));
    if(newNode == NULL)
    {
        printf("内存分配失败");
        return error;
    }
    newNode->data = data;
    newNode->next = NULL;
    while(current->next != NULL)
    {
        current = current->next;
    }
    current->next = newNode;
    return success;
}

Status DeleteList(Node *p, int e)
{
    LinkedList posNode = p->next;
    LinkedList posNodeFront = p;
    if(posNode == NULL)
    {
        printf("链表为空，无法删除\n");
    }
    else
    {
        while (posNode->data != e)
        {
            posNodeFront = posNode;
            posNode = posNode->next;
            if(posNode == NULL)
            {
                printf("没有数据\n");
                return error;
            }
        }
        posNodeFront->next = posNode->next;
        free(posNode);
        return success;
        
    }
}

 void TraverseList(LinkedList L)
 {
    LinkedList temp;
    temp = L->next;
    while(temp != NULL)
    {
        printf("%d\t",temp->data);
        temp = temp->next;
    }
    printf("\n");
 }

 Status SearchList(LinkedList L,int e)
 {
    while(L != NULL)
    {
        if(L->data == 0)
        {
            return success;
        }
    }
    return error;
 }

Status ReverseList(LinkedList *L)
{
    Node *newHead;
    Node *p1;
    Node *p2;
    p1=(*L)->next;
    p2=p1->next;
    p1->next=NULL;
    newHead=p1;
    while(p2!= NULL)
    {
        p1=p2;
        p2=p1->next;
        p1->next=newHead;
        newHead=p1;
    }
    (*L)->next=newHead; 
}

 Node* FindMidNode(LinkedList L)
 {
    LinkedList slow = L,fast = L;
    while(fast != NULL && slow != NULL)
    {
        fast = fast->next->next;
        slow = slow->next;
    }
    return slow;
 }

Status IsLoopList(LinkedList L)
{
    LinkedList fast = L,slow = L;
    while(fast != NULL && slow != NULL)
    {
        slow = slow->next;
        if((fast = fast->next->next) == NULL)
        return error;
        if(fast == slow)
        return success;
    }
    return error;
}

void Menu(void)
{
    printf("[1]   创建空链表\n");
    printf("[2]   销毁链表\n");
    printf("[3]   插入节点\n");
    printf("[4]   删除节点\n");
    printf("[5]   遍历链表\n");
    printf("[6]   查找数据\n");
    printf("[7]   反转链表\n");
    printf("[8]   判断链表是否成环\n");
    printf("[9]   奇偶调换\n");
    printf("[10]  查找中间节点\n");
    printf("[11]  退出\n");
    printf("\n请输入对应数字：");
};

int judge(void)
{
    int len, num = 0,arg = 1;
    char word[10];
    int m,j=1,k;
    while(j)
    {
        scanf("%s",word);
        len = strlen(word);
        for(m = 0;m<len;m++)
        {
            if(word[m]<'0' || word[m]>'9')
            {
                printf("请输入整数：");
                break;
            }
            else
            {
                if(m == len-1)
                    j=0;
            }
        }
    }
    j = len-1;
    for(m=0;m<len;m++)
    {
        for(k=0;k<j;k++)
            arg *= 10;
        num += (word[m]-'0')*arg;
        arg = 1;
        j--;
    }
    return num;
}

int main()
{
    int choice, num = 0;
    LinkedList head = NULL;

    do
    {
        Menu();//初始化菜单
        choice = judge();
        system("cls");
        switch(choice)
        {
            case 1://创建空链表
            {
                if(InitList(&head))
                {
                    printf("空链表创建成功\n");
                }
                else
                {
                    printf("空链表创建失败\n");
                }
                break;
            }
            case 2://销毁链表
            {
                DestoryList(&head);
                printf("链表销毁完成\n");
                break;
            }
            case 3://插入数据
            {
                if(head == NULL)
                {
                    printf("链表为空，请先创建链表\n");
                }
                else
                {
                    printf("请输入数据：\n");
                    scanf("%d",&num);
                    if(InsertList(head, num))
                    {
                        printf("数据插入成功\n");
                    }
                    else
                    {
                        printf("数据插入失败\n");
                    }
                }
                break;
            }
            case 4://删除节点
            {
                printf("请输入想删除的数据：");
                scanf("%d",&num);
                if(DeleteList(head,num))
                {
                    printf("数据删除成功\n");
                }
                else
                {
                    printf("数据删除失败\n");
                }
                break;
            }
            case 5://遍历链表
            {
                if(head == NULL || head->next == NULL)
                {
                    printf("链表不存在或只存在一个空的头节点\n");
                }
                else
                {
                    TraverseList(head);
                }
            }
            case 6:
            {
                printf("请输入你要查找的数据：");
                scanf("%d",&num);
                if(SearchList(head,num))
                {
                    printf("存在\n");
                }
                else
                {
                    printf("不存在\n");
                }
                break;
            }
            case 7://反转链表
            {
                if(head ==NULL || head->next == NULL)
                {
                    printf("链表为空或链表只含有两个节点\n");
                    printf("反转失败\n");
                }
                else
                {
                    if(ReverseList(&head))
                    printf("反转成功\n");
                    else
                    printf("反转失败\n");
                }
                break;
            }
            case 8://判断链表是否成环
            {
                if(head == NULL || head->next == NULL)
                {
                    printf("链表为空\n");
                }
                else
                {
                    if(IsLoopList(head))
                    {
                        printf("链表成环\n");
                    }
                    else
                    {
                        printf("链表没有成环\n");
                    }
                }
                break;
            }
            case 10://查找中间节点
            {
                if(head == NULL || head->next == NULL)
                {
                    printf("这是空链表\n");
                }
                else
                {
                    printf("链表中间储存的值为%d\n",(FindMidNode(head))->data);
                }
                break;
            }
            case 11://销毁链表
            {
                DestoryList(&head);
                break;
            }
            default:
            {
                printf("请重新输入!");
                break;
            }
        }
    }while(choice != 11);
    return 0;
}