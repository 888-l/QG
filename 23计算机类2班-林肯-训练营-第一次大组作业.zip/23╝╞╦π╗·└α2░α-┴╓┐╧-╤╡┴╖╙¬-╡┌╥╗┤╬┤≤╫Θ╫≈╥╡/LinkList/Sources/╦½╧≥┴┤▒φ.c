#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

typedef struct DuLNode{
    int data;
    struct DuLNode *prior, *next;
}DuLNode,*DuLinkedList;
typedef enum Status{
    error,
    success,
}Status;

Status DuLInitList(DuLinkedList *L);
void DuLDestoryList(DuLinkedList *L);
Status DuLInsertBeforeList(DuLNode *p,int data);
Status DuLInsertAfterList(DuLNode *p,int data);
Status DuLDeleteList(DuLNode *p,int *e);
void DuLTraverseList(DuLinkedList L);
void Menu(void);
int judge(void);

Status DuLInitList(DuLinkedList *L)
{
    DuLinkedList List;
    List = (DuLinkedList)malloc(sizeof(DuLNode));
    if(List == NULL)
    {
        printf("内存分配失败\n");
        return error;
    }
    List->next = NULL;
    List->prior = NULL;
    *L = List;
    return success;
}

void DuLDestoryList(DuLinkedList *L)
{
    DuLinkedList temp;
    while(*L != NULL)
    {
        temp = *L;
        *L = (*L)->next;
        free(temp);
    }
}

Status DuLInsertBeforeList(DuLNode *p,DuLNode *q)
{
    if(p->next == NULL)
    {
        p->next = q;
        q->prior = p;
    }
    else
    {
        DuLinkedList temp;
        temp = p->next;
        p->next = q;
        q->next = temp;
        temp->prior = q;
        q->prior = p;
        return success;
    }
}

Status DuLInsertAfterList(DuLNode *p,DuLNode *q)
{
    while(p->next != NULL)
    {
        p = p->next;
    }
    p->next = q;
    q->prior = p;
    return success;
}

Status DuLDeleteList(DuLNode *p,int *e)
{
    if(p->next == NULL)
    {
        printf("链表为空，无法删除\n");
        return error;
    }
    else
    {
        DuLinkedList posNode = p->next,posNodeFront = p;
        while (posNode->data != *e)
        {
            posNodeFront = posNode;
            posNode = posNode->next;
            if(posNode == NULL)
            {
                printf("找不到该数据\n");
                return error;
            }
        }
        if(posNode->next != NULL)
        {
            posNodeFront->next = posNode->next;
            posNode->next->prior = posNodeFront;
        }
        else
        {
            posNodeFront->next = NULL;
        }
        free(posNode);
        return success;
        
    }
}

void DuLTraverseList(DuLinkedList L)
{
    if(L == NULL)
    {
        printf("链表未创建，请先创建列表\n");
    }
    else if(L->next == NULL)
    {
        printf("当前链表为空\n");
    }
    else
    {
        DuLinkedList temp = L->next;
        while(temp != NULL)
        {
            printf("%d\t",temp->data);
            temp = temp->next;
        }
        printf("\n");
    }   
}

void Menu(void)
{
    printf("[1]  创建空链\n");
    printf("[2]  销毁链表\n");
    printf("[3]  头插法插入数据\n");
    printf("[4]  尾插法插入数据\n");
    printf("[5]  删除数据\n");
    printf("[6]  遍历链表\n");
    printf("[7]  退出");
    printf("\n请输入对应数字：");
}

int judge(void)
{
    int len,num = 0,arg = 1;
    char word[10];
    int m,j = 1,k;
    while(j)
    {
        scanf("%s",word);
        len = strlen(word);
        for(m=0;m<len;m++)
        {
            if(word[m]<'0' || word[m]>'9')
            {
                printf("请输入整数：");

                break;
            }
            else
            {
                if(m == len-1)
                {
                    j = 0;
                }
            }
        }
    }
    j = len -1;
    for(m=0;m<len;m++)
    {
        for(k=0;k<j;k++)
        {
            arg *= 10;
        }
        num += (word[m]-'0')*arg;
        arg = 1;
        j--;
    }
    return num;
}

int main(void){
    int choice,num = 0;
    DuLinkedList head;
    head = NULL;
    do
    {
        Menu();
        choice = judge();
        system("cls");
        switch(choice)
        {
            case 1://创建空链表
            {
                if(DuLInitList(&head))
                {
                    printf("空链表创建成功\n");
                }
                else
                {
                    printf("空链表创建失败\n");
                }
                break;
            }
            case 2://销毁链表
            {
                DuLDestoryList(&head);
                printf("链表销毁成功\n");
                break;
            }
            case 3://头插法插入数据
            {
                if(head == NULL)
                {
                    printf("链表未创建，请先创建链表\n");
                }
                else
                {
                    DuLinkedList newNode;
                    if(DuLInitList(&newNode))
                    {
                        printf("请输入数据：");
                        scanf("%d",&newNode->data);
                        if(DuLInsertBeforeList(head,newNode))
                        {
                            printf("数据插入成功\n");
                        }
                        else
                        {
                            printf("数据插入失败");
                        }

                    }
                }
                break;
            }
            case 4://尾插法插入数据
            {
                if(head == NULL)
                {
                    printf("链表未创建，请先创建链表\n");
                }
                else
                {
                    DuLinkedList newNode;
                    if(DuLInitList(&newNode))
                    {
                        printf("请输入数据：");
                        scanf("%d",&newNode->data);
                        if(DuLInsertAfterList(head,newNode))
                        {
                            printf("数据输入成功\n");
                        }
                        else
                        {
                            printf("数据插入失败\n");
                        }
                    }
                    else
                    {
                        printf("数据插入失败\n");
                    }
                }
                break;
            }
            case 5://删除数据
            {
                if(head==NULL)
                {
                    printf("链表未创建，请先创建链表\n");
                }
                else
                {
                    printf("输入要删除的数据：");
                    scanf("%d",&num);
                    if(DuLDeleteList(head,&num))
                    {
                        printf("数据删除成功\n");
                    }
                    else
                    {
                        printf("数据删除失败\n");
                    }
                }
                break;
            }
            case 6://遍历链表
            {
                DuLTraverseList(head);
                break;
            }
            case 7://退出
            {
                DuLDestoryList(&head);
                break;
            }
            default:
            {
                printf("请重新输入：");
                break;
            }
        }
    } while (choice != 7);
    return 0;
    
}